package main;

import java.awt.EventQueue;
import java.io.PrintStream;
import view.login;

public class main {
    public static void main(String[] args) {
        
        // Forzar que la consola de Eclipse muestre los prints
      
        System.out.println(">>> Aplicación iniciada"); // prueba
        
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login frame = new login();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}