package model;

import java.util.Date;

import libreria_generica.generic;

public class cuenta {
	private generic<Integer,Double>dts;
	private Date fecha;
	
	public cuenta() {
	    dts = new generic(0, 0, 0.0, 0.0);
	}
	public cuenta(int nCuenta,int movimiento,double saldo,double monto,Date fecha) {
		dts=new generic(nCuenta,movimiento,saldo,monto);
		this.fecha=fecha;
	}
	public void setNcuenta(int nCuenta) {
		dts.setAtribute1(nCuenta);
	}
	public void setMovimiento(int movimiento) {
		dts.setAtribute2(movimiento);
	}
	public void setSaldo(double saldo) {
		dts.setAtribute3(saldo);
	}
	public void setMonto(double monto) {
		dts.setAtribute4(monto);
	}
	public int getNcuenta() {
		return dts.getAtribute1();
	}
	public double getSaldo() {
		return dts.getAtribute3();
	}
	public int getMovimiento() {
		return dts.getAtribute2();
	}
	public double getMonto() {
		return dts.getAtribute4();
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha=fecha;
	}
	public String toString() {
	    return String.format(java.util.Locale.US, "%d;%d;%.2f;%.2f;%s%n",
	        getNcuenta(), getMovimiento(), getSaldo(), getMonto(), getFecha());
	}
	
}
