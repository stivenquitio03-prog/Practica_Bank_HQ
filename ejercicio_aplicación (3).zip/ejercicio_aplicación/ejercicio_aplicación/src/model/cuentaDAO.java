package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class cuentaDAO {
    private cuenta c;
    private final String path = System.getProperty("user.dir") + "/src/resources/";

    public cuentaDAO() {
        this.c = new cuenta();
        new java.io.File(path).mkdirs(); 
    }

    public cuentaDAO(cuenta c) {
        this.c = c;
        new java.io.File(path).mkdirs();
    }

    public void setCuenta(cuenta c) {
        this.c = c;
    }

    public boolean writerCuenta() throws IOException {
        FileWriter out = new FileWriter(path + c.getNcuenta() + ".txt", true);
        out.write(c.toString());
        out.close();
        System.out.println("[ARCHIVO]:"+c.getNcuenta() + ".txt");
        return true;
    }

    public cuenta getUltimaCuenta(int nCuenta) {
        cuenta ultima = null;
        try {
            BufferedReader br = new BufferedReader(
                new FileReader(path + nCuenta + ".txt"));
            String linea;
            String ultimaLinea = null;
            while ((linea = br.readLine()) != null) {
                ultimaLinea = linea;
            }
            br.close();
            if (ultimaLinea != null) {
                String[] datos = ultimaLinea.split(";");
                ultima = new cuenta();
                ultima.setNcuenta(Integer.parseInt(datos[0].trim()));
                ultima.setMovimiento(Integer.parseInt(datos[1].trim()));
                ultima.setSaldo(Double.parseDouble(datos[2].trim().replace(",", ".")));
                ultima.setMonto(Double.parseDouble(datos[3].trim().replace(",", ".")));
                ultima.setFecha(new Date());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ultima;
    }
}