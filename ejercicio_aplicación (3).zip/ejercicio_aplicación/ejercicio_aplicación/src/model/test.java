package model;

import java.io.IOException;
import java.util.Date;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		cuentaDAO cDAO = new cuentaDAO(new cuenta(123456, 1, 100.5, 0.0, new Date()));
		try {
			cDAO.writerCuenta();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}