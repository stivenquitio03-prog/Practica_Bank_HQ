package view;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import controller.logic_view_bank;
import java.awt.*;

public class view_bank extends JFrame {
    private static final long serialVersionUID = 1L;
    public JButton btn_cuentas;
    public JButton btn_depositos;
    public JButton btn_pagos;
    public JButton btn_consulta;
    private DefaultTableModel modeloTabla;
    private JTable tb_cuentas;

    public DefaultTableModel getTableModel() { return modeloTabla; }

    public view_bank() {
        setResizable(false);
        setTitle("BankSystem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 680, 380);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(24, 95, 165));
        setContentPane(root);

        // ── Topbar ──────────────────────────────────────────
        JPanel topbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        topbar.setBackground(new Color(24, 95, 165));
        topbar.setBorder(new EmptyBorder(4, 8, 4, 8));

        JLabel icoLbl = new JLabel("🏦");
        icoLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        JLabel titleLbl = new JLabel("BankSystem");
        titleLbl.setFont(new Font("Arial", Font.BOLD, 16));
        titleLbl.setForeground(Color.WHITE);
        JLabel subLbl = new JLabel("— Panel de operaciones");
        subLbl.setFont(new Font("Arial", Font.PLAIN, 12));
        subLbl.setForeground(new Color(255, 255, 255, 160));

        topbar.add(icoLbl);
        topbar.add(titleLbl);
        topbar.add(subLbl);

        // ── Body ────────────────────────────────────────────
        JPanel body = new JPanel(new BorderLayout()) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
            }
        };
        body.setOpaque(false);
        body.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel bodyInner = new JPanel(new BorderLayout());
        bodyInner.setBackground(Color.WHITE);
        bodyInner.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));

        // ── Sidebar ─────────────────────────────────────────
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(248, 249, 250));
        sidebar.setBorder(new CompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(220, 220, 220)),
            new EmptyBorder(16, 12, 16, 12)
        ));
        sidebar.setPreferredSize(new Dimension(155, 0));

        JLabel opLabel = new JLabel("OPERACIONES");
        opLabel.setFont(new Font("Arial", Font.BOLD, 10));
        opLabel.setForeground(new Color(150, 150, 150));
        opLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(opLabel);
        sidebar.add(Box.createVerticalStrut(10));

        btn_cuentas  = makeSideBtn("Cuentas",   new Color(24, 95, 165),  new Color(230, 241, 251));
        btn_depositos= makeSideBtn("Depósitos",  new Color(59, 109, 17),  new Color(234, 243, 222));
        btn_pagos    = makeSideBtn("Pagos",      new Color(163, 45, 45),  new Color(252, 235, 235));
        btn_consulta = makeSideBtn("Consultar",  new Color(15, 110, 86),  new Color(225, 245, 238));

        sidebar.add(btn_cuentas);
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(btn_depositos);
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(btn_pagos);
        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(btn_consulta);

        // ── Table area ──────────────────────────────────────
        JPanel tableArea = new JPanel(new BorderLayout());
        tableArea.setBackground(Color.WHITE);
        tableArea.setBorder(new EmptyBorder(14, 14, 14, 14));

        JLabel tableLabel = new JLabel("Historial de movimientos");
        tableLabel.setFont(new Font("Arial", Font.BOLD, 12));
        tableLabel.setForeground(new Color(100, 100, 100));
        tableLabel.setBorder(new EmptyBorder(0, 0, 10, 0));

        String[] columnas = {"Cuenta", "Depósitos", "Retiros", "Saldo"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tb_cuentas = new JTable(modeloTabla);
        tb_cuentas.setFont(new Font("Arial", Font.PLAIN, 13));
        tb_cuentas.setRowHeight(30);
        tb_cuentas.setShowVerticalLines(false);
        tb_cuentas.setGridColor(new Color(235, 235, 235));
        tb_cuentas.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tb_cuentas.getTableHeader().setBackground(new Color(248, 249, 250));
        tb_cuentas.getTableHeader().setForeground(new Color(100, 100, 100));
        tb_cuentas.getTableHeader().setBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)));
        tb_cuentas.setSelectionBackground(new Color(230, 241, 251));
        tb_cuentas.setSelectionForeground(new Color(24, 95, 165));

        // Alinear números a la derecha
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        for (int i = 1; i <= 3; i++) {
            tb_cuentas.getColumnModel().getColumn(i).setCellRenderer(rightRenderer);
        }

        JScrollPane scroll = new JScrollPane(tb_cuentas);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        scroll.getViewport().setBackground(Color.WHITE);

        tableArea.add(tableLabel, BorderLayout.NORTH);
        tableArea.add(scroll, BorderLayout.CENTER);

        bodyInner.add(sidebar, BorderLayout.WEST);
        bodyInner.add(tableArea, BorderLayout.CENTER);
        body.add(bodyInner, BorderLayout.CENTER);

        root.add(topbar, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);

        new logic_view_bank(this);
    }

    private JButton makeSideBtn(String text, Color accent, Color hoverBg) {
        JButton btn = new JButton(text) {
            protected void paintComponent(Graphics g) {
                if (getModel().isRollover()) {
                    g.setColor(hoverBg);
                    g.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                }
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Arial", Font.PLAIN, 13));
        btn.setForeground(new Color(50, 50, 50));
        btn.setBackground(new Color(248, 249, 250));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220)),
            new EmptyBorder(7, 12, 7, 12)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
        return btn;
    }
}