package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import controller.logic_view_login;
import java.awt.*;

public class login extends JFrame {
    private static final long serialVersionUID = 1L;
    public JTextField txt_user;
    public JButton btn_ok;
    public JPasswordField txt_psw;

    public login() {
        setTitle("BankSystem — Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setBounds(100, 100, 400, 420);
        setBackground(new Color(24, 95, 165));

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(new Color(24, 95, 165));
        setContentPane(root);

        // ── Header ──────────────────────────────────────────
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(new Color(24, 95, 165));
        header.setBorder(new EmptyBorder(30, 30, 20, 30));

        JLabel ico = new JLabel("🏦");
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        ico.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("BankSystem");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Ingresa tus credenciales");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(new Color(255, 255, 255, 180));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(ico);
        header.add(Box.createVerticalStrut(10));
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);

        // ── Body ────────────────────────────────────────────
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Color.WHITE);
        body.setBorder(new EmptyBorder(24, 28, 28, 28));

        body.add(makeLabel("Usuario"));
        body.add(Box.createVerticalStrut(6));
        txt_user = new JTextField();
        styleField(txt_user);
        body.add(txt_user);

        body.add(Box.createVerticalStrut(16));
        body.add(makeLabel("Contraseña"));
        body.add(Box.createVerticalStrut(6));
        txt_psw = new JPasswordField();
        styleField(txt_psw);
        body.add(txt_psw);

        body.add(Box.createVerticalStrut(22));
        btn_ok = new JButton("Iniciar sesión");
        btn_ok.setFont(new Font("Arial", Font.BOLD, 14));
        btn_ok.setBackground(new Color(24, 95, 165));
        btn_ok.setForeground(Color.WHITE);
        btn_ok.setFocusPainted(false);
        btn_ok.setBorderPainted(false);
        btn_ok.setOpaque(true);
        btn_ok.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn_ok.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn_ok.setAlignmentX(Component.CENTER_ALIGNMENT);
        body.add(btn_ok);

        JPanel bodyWrap = new JPanel(new BorderLayout()) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        bodyWrap.setOpaque(false);
        bodyWrap.setBorder(new EmptyBorder(0, 16, 16, 16));
        bodyWrap.add(body, BorderLayout.CENTER);

        root.add(header, BorderLayout.NORTH);
        root.add(bodyWrap, BorderLayout.CENTER);

        new logic_view_login(this);
    }

    private JLabel makeLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Arial", Font.BOLD, 12));
        lbl.setForeground(new Color(80, 80, 80));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            new EmptyBorder(4, 10, 4, 10)
        ));
    }
}