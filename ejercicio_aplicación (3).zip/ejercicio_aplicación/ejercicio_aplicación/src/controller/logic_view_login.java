package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JOptionPane;

import model.user;
import model.userDAO;
import view.login;
import view.view_bank;

public class logic_view_login implements ActionListener{
	private login vl;
	
	public logic_view_login(login vl) {
		super();
		this.vl=vl;
		this.vl.btn_ok.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==vl.btn_ok) {
			validar(vl.txt_user.getText(),getEchoPSW());
		}
		
	}
	/**
	 * Metodo para validar las credenciales de usuario
	 * @param c
	 * @return
	 */
	
	private boolean validar(String...c) {
		try {
			user u=new userDAO().getDataUser();
			if(u.getUser().equals(c[0])) {
				if(u.getPsw().equals(c[1])) {
					vl.setVisible(false);
					JOptionPane.showMessageDialog(vl, "Bienvenido al sistema","LOGIN",JOptionPane.INFORMATION_MESSAGE);
					view_bank bk=new view_bank();
					bk.setVisible(true);
					return true;
				}
			}
			JOptionPane.showMessageDialog(vl, "Credenciales incorrectas","LOGIN",JOptionPane.WARNING_MESSAGE);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(vl, "Fuente desconocida","LOGIN",JOptionPane.ERROR_MESSAGE);
		}
		return false;
		
	}
	private String getEchoPSW() {
		String psw="";
		for(char c:vl.txt_psw.getPassword()) {
			psw+=String.valueOf(c);
		}
		return psw;
	}
}
