package controller;

import java.io.IOException;
import java.util.Date;
import model.cuenta;
import model.cuentaDAO;

public class mgCuenta {
    private int ultimoNcuenta = -1;

    private int getRandom() {
        return (int)(Math.random() * 10);
    }

    private double getMonto() {
        return Math.round(Math.random() * 100 * 100.0) / 100.0;
    }
    

    public synchronized void createCuenta() {
    	 java.io.File carpeta = new java.io.File("src/resources/");
    	    if (!carpeta.exists()) {
    	        carpeta.mkdirs();
    	        System.out.println("[INFO] Carpeta src/resources/ creada.");
    	    }
        String numberCuenta = "12";
        for (int i = 0; i <= 7; i++) {
            numberCuenta += getRandom();
        }
        ultimoNcuenta = Integer.parseInt(numberCuenta);
        cuentaDAO dao = new cuentaDAO(
            new cuenta(ultimoNcuenta, 200, 0, 0, new Date()));
        try {
            dao.writerCuenta();
            System.out.println("========================================");
            System.out.println("[CUENTA CREADA] Número: " + ultimoNcuenta);
            System.out.println("========================================");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getUltimoNcuenta() {
        return ultimoNcuenta;
    }

    public synchronized void depositar(int nCuenta) {
        cuentaDAO dao = new cuentaDAO();
        cuenta ultima = dao.getUltimaCuenta(nCuenta);
        if (ultima != null) {
            double monto      = getMonto();
            double nuevoSaldo = ultima.getSaldo() + monto;
            cuenta nuevo = new cuenta(nCuenta, 1, nuevoSaldo, monto, new Date());
            try {
                dao.setCuenta(nuevo);
                dao.writerCuenta();
                System.out.printf(
                    "[DEPÓSITO]  Cuenta: %d | +%.2f | Saldo anterior: %.2f | Nuevo saldo: %.2f%n",
                    nCuenta, monto, ultima.getSaldo(), nuevoSaldo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void retirar(int nCuenta) {
        cuentaDAO dao = new cuentaDAO();
        cuenta ultima = dao.getUltimaCuenta(nCuenta);
        if (ultima != null) {
            double monto = getMonto();
            if (ultima.getSaldo() >= monto) {
                double nuevoSaldo = ultima.getSaldo() - monto;
                cuenta nuevo = new cuenta(nCuenta, 2, nuevoSaldo, monto, new Date());
                try {
                    dao.setCuenta(nuevo);
                    dao.writerCuenta();
                    System.err.printf(
                        "[RETIRO]    Cuenta: %d | -%.2f | Saldo anterior: %.2f | Nuevo saldo: %.2f%n",
                        nCuenta, monto, ultima.getSaldo(), nuevoSaldo);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.printf(
                    "[RECHAZADO] Cuenta: %d | Solicitado: %.2f | Saldo insuficiente: %.2f%n",
                    nCuenta, monto, ultima.getSaldo());
            }
        }
    }

    public synchronized java.util.List<Object[]> consultarResumen(int nCuenta) {
    	java.util.List<Object[]> filas = new java.util.ArrayList<>();
        String path = System.getProperty("user.dir") + "/src/resources/";
        try {
        	java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.FileReader(path + nCuenta + ".txt"));
            String linea;
            double totalDepositos = 0;
            double totalRetiros   = 0;
            double saldoActual    = 0;
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] datos = linea.split(";");
                int    mov    = Integer.parseInt(datos[1]);
                double monto  = Double.parseDouble(datos[3]);
                saldoActual   = Double.parseDouble(datos[2]);
                if (mov == 1) totalDepositos += monto;
                if (mov == 2) totalRetiros   += monto;
            }
            br.close();
            System.out.println("========================================");
            System.out.printf("[RESUMEN] Cuenta: %d%n", nCuenta);
            System.out.printf("  Total depósitos: %.2f%n", totalDepositos);
            System.out.printf("  Total retiros:   %.2f%n", totalRetiros);
            System.out.printf("  Saldo final:     %.2f%n", saldoActual);
            System.out.println("========================================");
            filas.add(new Object[]{
                nCuenta,
                String.format("%.2f", totalDepositos),
                String.format("%.2f", totalRetiros),
                String.format("%.2f", saldoActual)
            });
        } catch (Exception e) {
            System.out.println("[ERROR] No se pudo leer el archivo de cuenta: " + nCuenta);
            e.printStackTrace();
        }
        return filas;
    }
}