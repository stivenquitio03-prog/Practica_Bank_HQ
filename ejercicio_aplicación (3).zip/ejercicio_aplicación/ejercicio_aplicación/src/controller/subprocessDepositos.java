package controller;

public class subprocessDepositos extends Thread {
    private mgCuenta mga;
    private int nCuenta;
    private volatile boolean corriendo = true;

    public subprocessDepositos(mgCuenta mga, int nCuenta) {
        this.mga     = mga;
        this.nCuenta = nCuenta;
    }

    public void detener() {
        corriendo = false;
        this.interrupt();
    }

    @Override
    public void run() {
        while (corriendo) {
            try {
                mga.depositar(nCuenta);
                sleep(1500);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}