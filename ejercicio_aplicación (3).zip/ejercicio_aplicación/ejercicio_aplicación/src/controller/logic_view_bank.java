package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import view.view_bank;

public class logic_view_bank implements ActionListener {
    private view_bank vb;
    private mgCuenta mga;
    private int nCuentaActual = -1;
    private DefaultTableModel modelo;
    private subprocessDepositos hiloDepositos;
    private subprocessRetiros   hiloRetiros;

    public logic_view_bank(view_bank vb) {
        System.out.println(">>> logic_view_bank iniciado");
        this.vb     = vb;
        this.mga    = new mgCuenta();
        this.modelo = (DefaultTableModel) vb.getTableModel();
        vb.btn_cuentas.addActionListener(this);
        vb.btn_depositos.addActionListener(this);
        vb.btn_pagos.addActionListener(this);
        vb.btn_consulta.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if      (e.getSource() == vb.btn_cuentas)  crearCuenta();
        else if (e.getSource() == vb.btn_depositos) iniciarDepositos();
        else if (e.getSource() == vb.btn_pagos)     iniciarRetiros();
        else if (e.getSource() == vb.btn_consulta)  consultarYDetener();
    }

    private void crearCuenta() {
    	if (nCuentaActual != -1) {
            int opcion = JOptionPane.showConfirmDialog(vb,
                "Ya existe una cuenta activa: " + nCuentaActual +
                "\n¿Desea crear una nueva cuenta?",
                "CUENTAS", JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (opcion != JOptionPane.YES_OPTION) return;

            if (hiloDepositos != null && hiloDepositos.isAlive()) hiloDepositos.detener();
            if (hiloRetiros   != null && hiloRetiros.isAlive())   hiloRetiros.detener();
            try {
                if (hiloDepositos != null) hiloDepositos.join(2000);
                if (hiloRetiros   != null) hiloRetiros.join(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // ← ELIMINADO modelo.setRowCount(0) para conservar datos en tabla
            System.out.println(">>> Cuenta anterior " + nCuentaActual + " cerrada.");
        }

        Thread hilo = new Thread(() -> {
            mga.createCuenta();
            nCuentaActual = mga.getUltimoNcuenta();
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(vb,
                    "Cuenta creada: " + nCuentaActual,
                    "CUENTAS", JOptionPane.INFORMATION_MESSAGE);
                System.out.println(">>> Cuenta activa: " + nCuentaActual);
            });
        });
        hilo.start();
        try {
            hilo.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void iniciarDepositos() {
        if (nCuentaActual == -1) {
            JOptionPane.showMessageDialog(vb, "Primero cree una cuenta",
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (hiloDepositos == null || !hiloDepositos.isAlive()) {
            hiloDepositos = new subprocessDepositos(mga, nCuentaActual);
            hiloDepositos.setDaemon(true);
            hiloDepositos.start();
            System.out.println("[HILO DEPÓSITOS] Iniciado para cuenta: " + nCuentaActual);
        } else {
            System.out.println("[HILO DEPÓSITOS] Ya está corriendo.");
        }
    }

    private void iniciarRetiros() {
        if (nCuentaActual == -1) {
            JOptionPane.showMessageDialog(vb, "Primero cree una cuenta",
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (hiloRetiros == null || !hiloRetiros.isAlive()) {
            hiloRetiros = new subprocessRetiros(mga, nCuentaActual);
            hiloRetiros.setDaemon(true);
            hiloRetiros.start();
            System.out.println("[HILO RETIROS] Iniciado para cuenta: " + nCuentaActual);
        } else {
            System.out.println("[HILO RETIROS] Ya está corriendo.");
        }
    }

    private void consultarYDetener() {
        if (nCuentaActual == -1) {
            JOptionPane.showMessageDialog(vb, "No hay cuenta activa",
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (hiloDepositos != null && hiloDepositos.isAlive()) {
            hiloDepositos.detener();
            System.out.println("[HILO DEPÓSITOS] Detenido.");
        }
        if (hiloRetiros != null && hiloRetiros.isAlive()) {
            hiloRetiros.detener();
            System.out.println("[HILO RETIROS] Detenido.");
        }
        try {
            if (hiloDepositos != null) hiloDepositos.join(3000);
            if (hiloRetiros   != null) hiloRetiros.join(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        java.util.List<Object[]> filas = mga.consultarResumen(nCuentaActual);
        for (Object[] fila : filas) {
            modelo.addRow(fila);
        }

        JOptionPane.showMessageDialog(vb,
            "Procesos detenidos.\nResumen agregado a la tabla.",
            "CONSULTA", JOptionPane.INFORMATION_MESSAGE);
    }
}