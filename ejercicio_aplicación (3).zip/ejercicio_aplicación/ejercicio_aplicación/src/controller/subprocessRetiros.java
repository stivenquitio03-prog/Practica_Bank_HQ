package controller;

public class subprocessRetiros extends Thread {
    private mgCuenta mga;
    private int nCuenta;
    private volatile boolean corriendo = true;

    public subprocessRetiros(mgCuenta mga, int nCuenta) {
        this.mga     = mga;
        this.nCuenta = nCuenta;
    }

    public void detener() {
        corriendo = false;
        this.interrupt();
    }

    @Override
    public void run() {
        while (corriendo) {
            try {
                mga.retirar(nCuenta);
                sleep(2000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}