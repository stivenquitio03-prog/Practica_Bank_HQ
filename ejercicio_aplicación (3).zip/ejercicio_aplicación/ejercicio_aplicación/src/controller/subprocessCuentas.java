package controller;

public class subprocessCuentas extends Thread {
    private mgCuenta mga;

    public subprocessCuentas(mgCuenta mga) {
        this.mga = mga;
    }

    @Override
    public void run() {
        try {
            sleep(1000);
            mga.createCuenta();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}